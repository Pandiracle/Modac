<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'modak' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Gs}1TTpySY2c(q]qZ=KtPC{gB<<L[HeT$uTKJW~a?;..3f!^TPM[yf(,=I3b{{AB' );
define( 'SECURE_AUTH_KEY',  '53pG/v8]#|B/Lrk%X`8[4o6o]%TzWJ_pTU`bFa@aCnAK3HM.Rx~T)<d?r7!biUj/' );
define( 'LOGGED_IN_KEY',    '8ZFKR9?)-#l)_o}ft(,~!XnywSO^R(OrK{WifmS[;3t@&/u <Q[2xVdvG]Skasv.' );
define( 'NONCE_KEY',        '}(1y[Mn0J^,@8dWA0XRn-]qI!grOK+%nL>%Vawh2E&yFZ&{}TmAB_LdH%[XQ``<K' );
define( 'AUTH_SALT',        '6Y`bY`ZNXz$jOU xrEUyo=!4Nlk*6]!b~zykGTyuvDRDw0Stf:%]:E%,Atj ( c+' );
define( 'SECURE_AUTH_SALT', '=oRJ)Ni,P<+{Xvm2uBVFI~r9e[EkI<<GJ&VG6jER-honHMNCm=, u=o*;~o[2TfC' );
define( 'LOGGED_IN_SALT',   '/T={|7L8AL];!59n>vHDT$w&(%cVzWD+hdwnWpbTgkT[*/EKM4/>?K=6@5dR2,=&' );
define( 'NONCE_SALT',       'OXA}Tn.{&7k5K!tj2ji:oi*0;=Lq%ISXj%wu+q;gbhs`acGr8$;&Px|T+w8qIagv' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
