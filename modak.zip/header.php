<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package modak
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>



<div id="dtr-wrapper" class="clearfix"> 

     
    <!-- Small Devices Header 
============================================= -->
    <div class="dtr-responsive-header fixed-top">
        <div class="container"> 
            
            <!-- small devices logo --> 
            <a href="index.html"><img src="<?php echo get_template_directory_uri(  );?>/assets/images/logo-dark.png" alt="logo"></a> 
            <!-- small devices logo ends --> 
            
            <!-- menu button -->
            <button id="dtr-menu-button" class="dtr-hamburger" type="button"><span class="dtr-hamburger-lines-wrapper"><span class="dtr-hamburger-lines"></span></span></button>
        </div>
        <div class="dtr-responsive-header-menu"></div>
    </div>
    <!-- Small Devices Header ends 
============================================= --> 
    
    <!-- Header 
============================================= -->
    <header id="dtr-header-global" class="fixed-top">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between"> 
                
                <!-- header left starts -->
                <div class="dtr-header-left"> 
                    
                    <!-- logo --> 
                    <a class="logo-default dtr-scroll-link" href="#home"><img src="<?php echo get_template_directory_uri(  );?>/assets/images/logo-dark.png" alt="logo" width="108"></a> 
                    
                    <!-- logo on scroll --> 
                    <a class="logo-alt dtr-scroll-link" href="#home"><img src="<?php echo get_template_directory_uri(  );?>/assets/images/logo-dark.png" alt="logo" width="108"></a> 
                    <!-- logo on scroll ends --> 
                    
                </div>
                <!-- header left ends --> 
                
                <!-- menu starts-->
                <div class="dtr-header-right">
                    <?php
			wp_nav_menu(
				array(
					'theme_location' => 'menu-1',
          'menu_id'        => 'primary-menu',
          'container' => 'div',
          'container_class' => 'main-navigation dtr-menu-dark',
          'menu_class' => 'sf-menu dtr-scrollspy dtr-nav dark-nav-on-load dark-nav-on-scroll',
				)
			);
			?>  







                </div>
                <!-- menu ends --> 
                
            </div>
        </div>
    </header>
    <!-- header ends
================================================== --> 

<!-- == main content area starts == -->
<div id="dtr-main-content"> 


