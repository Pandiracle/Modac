<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package modak
 */

?>

   <!-- footer section starts
================================================== -->
<footer id="dtr-footer"> 
            
            <!--== copyright starts ==-->
            <div class="dtr-copyright">
                <div class="container"> 
                    
                    <!--== row starts ==-->
                    <div class="row"> 
                        
                        <!-- column 1 starts -->
                        <div class="col-12 col-md-6">
                            <p> Copyright © Modak 2020. All rights reserved.</p>
                        </div>
                        <!-- column 1 ends --> 
                        
                        <!-- column 2 starts -->
                        <div class="col-12 col-md-6 text-right">
                            <ul class="dtr-pipe-list">
                                <li><a href="#">Privacy Policy</a></li>
                                <li><a href="#">Terms of Use</a></li>
                            </ul>
                        </div>
                        <!-- column 2 ends --> 
                        
                    </div>
                    <!--== row ends ==--> 
                    
                </div>
            </div>
            <!--== copyright ends ==--> 
            
        </footer>
        <!-- footer section ends
================================================== --> 


  </div>
    <!-- == main content area ends == --> 
    
</div>
<!-- #dtr-wrapper ends --> 
<?php wp_footer(); ?>

</body>
</html>
