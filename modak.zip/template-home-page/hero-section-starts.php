  <!-- hero section starts
================================================== -->
<section id="home" class="dtr-section dtr-hero-section-top-padding dtr-pb-100">
            <div class="container"> 
                
                <!--===== row 1 starts =====-->
                <div class="row"> 
                    
                    <!-- column 1 starts -->
                    <div class="col-12 col-md-6"> 
                    <?php while( have_rows('title') ): the_row(); 

// переменные

$first = get_sub_field('first');
$second = get_sub_field('second');
$three = get_sub_field('three');
?>
                        <!-- intro text -->
                        <p class="text-size-xxl font-weight-300 color-dark"><?php echo $first;?></p>
                        <p class="text-size-xxl color-dark"><span class="font-weight-300"><?php echo $second;?> </span><span class="font-weight-500"><?php echo $three;?></span></p>
                        <div class="spacer-20"></div>
                        <?php while( have_rows('profession') ): the_row(); 

// переменные

$first_profession = get_sub_field('first_profession');
$second_profession = get_sub_field('second_profession');
$three_profession = get_sub_field('three_profession');
$four_profession = get_sub_field('four_profession');
?>
                        <!-- animated text starts -->
                        <h3 class="dtr-mb-5 color-blue"><?php echo $first_profession;?></h3>
                        <h3 class="dtr-mb-5 color-blue opacity-1"><?php echo $second_profession;?></h3>
                        <h3><span class="dtr-animated-headline push"> <span class="dtr-words-wrapper"> 
                            
                            <!-- first visible word --> 
                            <b class="is-visible"><span class="color-blue opacity-2"><?php echo $three_profession;?></span></b> 
                            <!-- first visible word ends --> 
                            
                            <!-- second word --> 
                            <b class="is-hidden"><span class="color-blue opacity-2"><?php echo $four_profession;?></span></b> 
                            <!-- second word ends --> 
                            
                            </span> </span></h3>
                        <!-- animated text ends --> 
                        <?php endwhile; ?>              
                    </div>
                    <!-- column 1 ends --> 
                    <?php endwhile; ?>           
                    <!-- column 2 starts -->
                    <div class="col-12 col-md-6"> 
                        
                        <!--=== img slider - 3col starts ===-->
                        <div class="dtr-slick-slider dtr-img-slider-3col dtr-rounded-img"> 
                        <?php while( have_rows('first_slide') ): the_row(); 

// переменные

$img = get_sub_field('img');

?>
                            <div> <img src="<?php echo $img;?>" alt="image"> </div>
               
                            <?php endwhile; ?> 
                        </div>
                        <!--=== img slider - 3col ends ===--> 
                        
                        <!--=== img slider - 2col starts ===-->
                        <div class="row dtr-mt-30">
                            <div class="col-12 col-md-8 offset-md-4">
                                <div class="dtr-slick-slider dtr-img-slider-2col dtr-rounded-img"> 
                                <?php while( have_rows('second_slide') ): the_row(); 

// переменные

$img = get_sub_field('img');

?>
                                    <!-- img 1 -->
                                    <div> <img src="<?php echo $img;?>" alt="image"> </div>
                                    <?php endwhile; ?> 
                                </div>
                            </div>
                        </div>
                        <!--=== img slider - 2col ends ===--> 
                        
                    </div>
                    <!-- column 2 ends --> 
                    
                </div>
                <!--===== row 1 ends =====--> 
                <!--===== row 2 starts =====-->
                <div class="row dtr-mt-30"> 
                    
                    <!-- column 1 starts -->
                    <div class="col-12 col-md-10"> 
                        
                        <!-- text -->
                        <p class="text-size-md">I help our clients create <span class="font-weight-500 color-dark">brands</span>, build digital <span class="font-weight-500 color-dark">products</span> and <span class="font-weight-500 color-dark">services</span>, innovate, find opportunities and validate ideas.</p>
                        
                        <!-- social starts -->
                        <ul class="dtr-social dtr-social-list dtr-styled-social text-left dtr-mt-30">
                            <li class="dtr-social-title font-weight-500 color-dark">Follow Me on</li>
                            <?php while( have_rows('social_links') ): the_row(); 

// переменные

$inst = get_sub_field('inst');
$facebook = get_sub_field('facebook');
$in = get_sub_field('in');
?>
                            <li><a href="<?php echo $inst; ?>" class="dtr-social-button dtr-instagram" target="_blank" title="instagram"><span>Follow on Instagram</span></a></li>
                            <li><a href="<?php echo $facebook; ?>" class="dtr-social-button dtr-facebook" target="_blank" title="facebook"><span>Like On Facebook</span></a></li>
                            <li><a href="<?php echo $in; ?>" class="dtr-social-button dtr-linkedin" target="_blank" title="linkedin"><span>View My Profile</span></a></li>
                            <?php endwhile; ?> 
                        </ul>
                        <!-- social ends --> 
                        
                    </div>
                    <!-- column 1 ends --> 
                    
                    <!-- column 2 starts -->
                    <div class="col-12 col-md-2 dtr-rounded-img small-device-space"> <img src="<?php echo get_template_directory_uri(  ); ?>/assets/images/experience-img.jpg" alt="image"> </div>
                    <!-- column 2 ends --> 
                    
                </div>
                <!--===== row 2 ends =====--> 
                
            </div>
        </section>
        <!-- hero section ends
================================================== --> 