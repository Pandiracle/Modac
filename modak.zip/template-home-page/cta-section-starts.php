      
        
        <!-- cta section starts
================================================== -->
<section class="dtr-section parallax dtr-py-100" style="background-image: url(assets/images/background-cta.jpg);">
            <div class="container"> 
                
                <!--== row starts ==-->
                <div class="row text-center">
                    <div class="col-12">
                        <h3 class="font-family-alt font-weight-700 color-dark">Want to work together!</h3>
                        <p class="color-dark text-size-md">I’m available for freelance work.</p>
                        <!-- link starts --> 
                        <a href="#" class="dtr-btn btn-white dtr-mt-30">Hire Me <i class="icon-chevron-compact-right"></i></a> 
                        <!-- link ends --> 
                    </div>
                </div>
                <!--== row ends ==--> 
                
            </div>
        </section>
        <!-- cta section ends
================================================== --> 