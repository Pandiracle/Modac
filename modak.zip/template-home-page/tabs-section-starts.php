 <!-- tabs section starts
================================================== -->
        <section id="services" class="dtr-section dtr-py-100">
            <div class="container"> 
                
                <!-- heading starts -->
                <div class="dtr-styled-heading">
                    <h2>What I Offer</h2>
                    <p>Subheading or information goes here</p>
                </div>
                <!-- heading ends --> 
                
                <!-- tabs starts -->
                <div class="row d-flex align-items-center dtr-styled-tab"> 
                    
                    <!-- left (nav) column starts -->
                    <div class="col-12 col-md-4">
                        <div class="nav flex-column nav-pills" role="tablist" aria-orientation="vertical"> 
                            
                        
                            <?php $i=1; while( have_rows('name') ): the_row(); 
                        ?>
    <a class="nav-link <?php if($i == 1) echo"active"?>" id="services-tab-<?php echo $i;?>-tab" data-toggle="pill" href="#services-tab-<?php echo $i;?>" role="tab" aria-controls="services-tab-<?php echo $i;?>" aria-selected="false">
                            <h4><?php echo get_sub_field('name');?></h4>
                            </a> 
                           <?php $i++;?> 
                       <?php  endwhile; ?>  
                     
                            
                        </div>
                    </div>
                    <!-- left (nav) column ends --> 
                    
                    <!-- right (content) column starts -->
                    <div class="col-12 col-md-7 offset-md-1 small-device-space">
                        <div class="tab-content" id="v-pills-tabContent"> 
                            
                       
                            
                            <?php $i=1; while( have_rows('content') ): the_row(); 
                        ?>
   

     <div class="tab-pane fade <?php if($i == 1) echo "show active";?>" id="services-tab-<?php echo $i;?>" role="tabpanel" aria-labelledby="services-tab-<?php echo $i;?>-tab"> 
                                <div class="row">
                                    <div class="col-12 col-md-5 small-device-space"> <img src="<?php echo get_sub_field('img');?>" alt="image"> </div>
                                    <div class="col-12 col-md-7">
                                        <h6><?php echo get_sub_field('blue');?></h6>
                                        <p><?php echo get_sub_field('blu');?></p>
                                    </div>
                                </div>

                                
                            </div>




                           <?php $i++;?> 
                       <?php  endwhile; ?>  



                            
                        </div>
                    </div>
                    <!-- right (content) column ends --> 
                    
                </div>
                <!-- tabs starts --> 
                
            </div>
        </section>
        <!-- tabs section ends
================================================== --> 