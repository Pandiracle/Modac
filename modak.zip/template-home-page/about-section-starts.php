
<!-- about section starts
================================================== -->
<section id="about" class="dtr-section dtr-py-100 bg-light-blue">
            <div class="container"> 
                
                <!--===== row 1 starts =====-->
                <div class="row d-flex align-items-center"> 
                    
                    <!-- column 1 starts -->
                    <div class="col-12 col-md-6 small-device-space">
                        <div class="dtr-pr-30"> <img src="<?php echo get_field('img');?>" alt="image"> </div>
                    </div>
                    <!-- column 1 ends --> 
                    
                    <!-- column 2 starts -->
                    <div class="col-12 col-md-6"> 
                        
                        <!-- heading starts -->
                        <div class="dtr-styled-heading">
                            <h2>About Me</h2>
                            <p>Subheading or information goes here</p>
                        </div>
                        <!-- heading ends --> 
                        
                        <!-- text -->
                        <?php while( have_rows('text') ): the_row(); 
                        ?>
                        <p class="font-weight-500 color-dark"><?php echo get_sub_field('blue');?></p>
                        <p class="dtr-mt-20"><?php echo get_sub_field('blu');?></p>
                        <?php endwhile; ?>   
                        <!--== nested row starts ==-->
                        <div class="row dtr-mt-30"> 
                        <?php while( have_rows('prize') ): the_row(); 
                        ?>
                            <!-- nested column 1 starts -->
                            <div class="col-12 col-md-4 small-device-space"> <img src="<?php echo get_sub_field('img');?>" alt="image"> </div>
                            <!-- nested column 1 ends --> 
                            
                            <!-- nested column 2 starts -->
                            <div class="col-12 col-md-8">
                                <p class="font-weight-500 color-dark dtr-mb-0"><?php echo get_sub_field('blue');?></p>
                                <p><?php echo get_sub_field('blu');?></p>
                            </div>
                            <!-- nested column 2 ends --> 
                            <?php endwhile; ?>  
                        </div>
                        <!--== nested row starts ==--> 
                        
                    </div>
                    <!-- column 2 ends --> 
                    
                </div>
                <!--===== row 1 ends =====--> 
                
                <!--===== row 2 starts =====-->
                <div class="row dtr-mt-100"> 
                    
               

                    <?php while( have_rows('attainment') ): the_row(); 
                        ?>
   
     <div class="col-12 col-md-3 small-device-space">
                        <p class="font-weight-500 color-dark dtr-mb-0"><?php echo get_sub_field('name');?></p>
                    </div>
                       <?php endwhile; ?> 
                </div>
                <!--===== row 2 ends =====--> 
                
            </div>
        </section>
        <!-- about section ends
================================================== --> 