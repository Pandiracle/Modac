  <!-- pricing section starts
================================================== -->
<section id="pricing" class="dtr-section dtr-py-100 bg-light-blue">
            <div class="container"> 
                
                <!-- heading starts -->
                <div class="dtr-styled-heading">
                    <h2>Plans & Pricing</h2>
                    <p>Subheading or information goes here</p>
                </div>
                <!-- heading ends --> 
                
                <!--== row starts ==-->
                <div class="row"> 
                    
                 
   
                    <?php $i=1; while( have_rows('content') ): the_row(); 
                        ?>
   

     
   <!-- column 1 starts -->
   <div class="col-12 col-md-4"> 
                        
                        <!-- pricing 1 starts -->
                        <div class="dtr-pricing <?php if($i==2) echo "pricing-focused bg-dark-grey"; else echo "bg-white"; ?>">
                        <?php if($i==2) echo "<div class=\"dtr-focus-border bg-blue\"></div>"; ?>
                            <div class="dtr-pricing-img color-blue"><i class="<?php echo get_sub_field('name_icon');?>"></i></div>
                            <h4 class="dtr-pricing-heading"><?php echo get_sub_field('name');?></h4>
                            <p class="dtr-price color-blue"><sup>$</sup><?php echo get_sub_field('price');?></p>
                            <p class="font-weight-500 color-dark">Includes:</p>
                            <ul class="dtr-list-pricing">
                            <?php while( have_rows('includes') ): the_row(); 
                        ?>
                                <li><?php echo get_sub_field('name');?></li>
                                <?php  endwhile; ?>  
                            </ul>
                            <a href="#" class="dtr-btn btn-blue dtr-mt-30">Contact Me</a> </div>
                        <!-- pricing 1 ends --> 
                        
                    </div>
                    <!-- column 1 ends --> 
                    



                           <?php $i++;?> 
                       <?php  endwhile; ?>  



                    
                </div>
                <!--== row ends ==--> 
                
            </div>
        </section>
        <!-- pricing section ends
================================================== --> 