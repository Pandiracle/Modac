 <!-- testimonial section starts
================================================== -->
<section  id="testimonial" class="dtr-section overflow-hidden dtr-py-100 bg-light-blue">
            <div class="container"> 
                
                <!-- heading starts -->
                <div class="dtr-styled-heading heading-center">
                    <h2>Testimonial</h2>
                    <p>Subheading or information goes here</p>
                </div>
                <!-- heading ends --> 
                
                <!--===== row 1 starts =====-->
                <div class="row">
                    <div class="col-12"> 
                        <!-- quote icon -->
                        <div class="dtr-testimonial-icon color-blue"></div>
                        
                        <!--===== testimonial slider starts =====-->
                        <div class="dtr-slick-slider dtr-testimonial-style-center"> 
                            
                          
                            

                            <?php while( have_rows('content') ): the_row(); 
                        ?>
   

   



 <div class="dtr-testimonial">
                                <div class="dtr-testimonial-content"><?php echo   get_sub_field('text');?></div>
                                <div class="dtr-testimonial-stars dtr-stars-<?php echo   get_sub_field('count_star');?> color-blue"></div>
                                <div class="dtr-client-info"> <img src="<?php echo   get_sub_field('img');?>" alt="image">
                                    <h5 class="dtr-client-name"><?php echo   get_sub_field('name');?></h5>
                                    <span class="dtr-client-job"><?php echo   get_sub_field('company');?></span></div>
                            </div>
                           
                    
                       <?php  endwhile; ?>  


                            
                        </div>
                        <!--===== testimonial slider ends =====--> 
                        
                    </div>
                </div>
                <!--===== row 1 ends =====--> 
                
            </div>
        </section>
        <!-- testimonial section ends
================================================== --> 