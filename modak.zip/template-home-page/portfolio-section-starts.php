 <!-- portfolio section starts
================================================== -->
<section id="portfolio" class="dtr-section dtr-py-100">
            <div class="container"> 
                
                <!-- heading starts -->
                <div class="dtr-styled-heading heading-center">
                    <h2>Some Inspiration</h2>
                    <p>Subheading or information goes here</p>
                </div>
                <!-- heading ends --> 
                
                <!-- portfolio grid starts -->
                <div class="dtr-portfolio-grid dtr-portfolio-grid-4col dtr-portfolio-style-1 dtr-rounded-img clearfix"> 
                    
            
                    
                  


                    <?php while( have_rows('images') ): the_row(); ?>

      
        <div class="dtr-portfolio-item">
                        <div class="dtr-portfolio-content"> <img src="<?php echo get_sub_field('img');?>" alt="image">
                            <div class="dtr-portfolio-overlay"> <a class="media-zoom popup-gallery" href="<?php echo get_sub_field('img');?>"></a> </div>
                        </div>
                    </div>
          

                       <?php  endwhile; ?>  

                    
                </div>
                <!-- portfolio grid ends --> 
                
            </div>
        </section>
        <!-- portfolio section ends
================================================== --> 