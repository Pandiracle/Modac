<?php

/**
 * Template name: Home page
 */
?>    
<?php
 get_header();

?>
   
<?php while( have_posts() ) : the_post();
                
                        the_content(); // выводим контент
                    endwhile; ?>

<?php 
    get_footer();
?>

